-- ---------------------------------------------------------
		--
		-- SIMPLE SQL Dump
		-- 
		-- nawa (at) yahoo (dot) com
		--
		-- Host Connection Info: localhost via TCP/IP
		-- Generation Time: August 08, 2018 at 18:55 PM ( Asia/Manila )
		-- PHP Version: 7.2.7
		--
		-- ---------------------------------------------------------


		SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
		SET time_zone = "+00:00";
		/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
		/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
		/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
		/*!40101 SET NAMES utf8 */;
		

		-- ---------------------------------------------------------
		--
		-- Table structure for table : `announcements`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `announcements` (
  `announcement_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `company_id` int(111) NOT NULL,
  `location_id` int(111) NOT NULL,
  `department_id` int(111) NOT NULL,
  `published_by` int(111) NOT NULL,
  `summary` text NOT NULL,
  `description` text NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`announcement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `attendance_time`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `attendance_time` (
  `time_attendance_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `attendance_date` varchar(255) NOT NULL,
  `clock_in` varchar(255) NOT NULL,
  `clock_out` varchar(255) NOT NULL,
  `clock_in_out` varchar(255) NOT NULL,
  `time_late` varchar(255) NOT NULL,
  `early_leaving` varchar(255) NOT NULL,
  `overtime` varchar(255) NOT NULL,
  `total_work` varchar(255) NOT NULL,
  `total_rest` varchar(255) NOT NULL,
  `attendance_status` varchar(100) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`time_attendance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `attendance_time`
		--
		INSERT INTO `attendance_time` (`time_attendance_id`, `employee_id`, `attendance_date`, `clock_in`, `clock_out`, `clock_in_out`, `time_late`, `early_leaving`, `overtime`, `total_work`, `total_rest`, `attendance_status`, `remarks`) VALUES
(1, 31, '2018-07-29', '2018-07-29 04:13:31', '2018-08-07 15:56:07', 0, '2018-07-29 04:13:31', '2018-08-07 15:56:07', '2018-08-07 15:56:07', '0:0', '', 'Present', ''),
(15, 39, '2018-08-06', '2018-08-06 15:55:09', '2018-08-07 15:56:07', 0, '2018-08-06 15:55:09', '2018-08-07 15:56:07', '2018-08-07 15:56:07', '0:0', '', 'Present', ''),
(16, 39, '2018-08-07', '2018-08-07 15:57:00', '2018-08-07 00:00:00', 0, '2018-08-07 15:57:00', '2018-08-07 00:00:00', '2018-08-07 00:00:00', '15:57', '', 'Present', ''),
(18, 31, '2018-08-08', '2018-08-08 09:29:08', '2018-08-08 11:29:08', 0, '2018-08-08 09:29:08', '2018-08-08 11:29:08', '2018-08-08 11:29:08', '2:0', '', 'Present', ''),
(19, 39, '2018-08-08', '2018-08-08 09:29:08', '2018-08-08 11:29:08', 0, '2018-08-08 09:29:08', '2018-08-08 11:29:08', '2018-08-08 11:29:08', '2:0', '', 'Present', ''),
(20, 36, '2018-08-08', '2018-08-08 09:29:08', '2018-08-08 11:29:08', 0, '2018-08-08 09:29:08', '2018-08-08 11:29:08', '2018-08-08 11:29:08', '2:0', '', 'Present', ''),
(21, 39, '2018-08-08', '2018-08-08 09:29:08', '2018-08-08 12:29:08', 0, '2018-08-08 09:29:08', '2018-08-08 12:29:08', '2018-08-08 12:29:08', '3:0', '', 'Present', ''),
(22, 37, '2018-08-08', '2018-08-08 09:29:08', '2018-08-08 11:29:08', 0, '2018-08-08 09:29:08', '2018-08-08 11:29:08', '2018-08-08 11:29:08', '2:0', '', 'Present', ''),
(23, 40, '2018-08-08', '2018-08-08 09:29:08', '2018-08-08 11:29:08', 0, '2018-08-08 09:29:08', '2018-08-08 11:29:08', '2018-08-08 11:29:08', '2:0', '', 'Present', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `award_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `award_type` (
  `award_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `award_type` varchar(200) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`award_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `award_type`
		--
		INSERT INTO `award_type` (`award_type_id`, `award_type`, `created_at`) VALUES
(1, 'Performer of the Year', '28-04-2017'),
(2, 'Most Consistent Employee', '28-04-2017'),
(3, 'Employee of the Month', '28-04-2017'),
(4, 'Employee of the Year', '28-04-2017'),
(5, 'Hard Worker Award', '28-04-2017'),
(6, 'Certificate of Excellence', '28-04-2017'),
(7, 'Certificate of Project Completion', '28-04-2017'),
(8, 'Outstanding Leadership', '28-04-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `awards`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `awards` (
  `award_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(200) NOT NULL,
  `award_type_id` int(200) NOT NULL,
  `gift_item` varchar(200) NOT NULL,
  `cash_price` varchar(200) NOT NULL,
  `award_photo` varchar(255) NOT NULL,
  `award_month_year` varchar(200) NOT NULL,
  `award_information` text NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`award_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `awards`
		--
		INSERT INTO `awards` (`award_id`, `employee_id`, `award_type_id`, `gift_item`, `cash_price`, `award_photo`, `award_month_year`, `award_information`, `description`, `created_at`) VALUES
(3, 31, 1, 1, 1, 'award_1531690689.png', '2018-07', 'a', '&lt;p&gt;a&lt;/p&gt;', '2018-07-16');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `chat_messages`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `chat_messages` (
  `message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_id` varchar(40) NOT NULL DEFAULT '',
  `to_id` varchar(50) NOT NULL DEFAULT '',
  `message_frm` varchar(255) NOT NULL,
  `message_to` varchar(255) NOT NULL,
  `from_uname` varchar(225) NOT NULL DEFAULT '',
  `to_uname` varchar(255) NOT NULL DEFAULT '',
  `message_content` longtext NOT NULL,
  `message_date` varchar(255) DEFAULT NULL,
  `recd` tinyint(1) NOT NULL DEFAULT '0',
  `message_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `companies`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `companies` (
  `company_id` int(111) NOT NULL AUTO_INCREMENT,
  `type_id` int(111) NOT NULL,
  `name` varchar(255) NOT NULL,
  `trading_name` varchar(255) NOT NULL,
  `registration_no` varchar(255) NOT NULL,
  `government_tax` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `website_url` varchar(255) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `companies`
		--
		INSERT INTO `companies` (`company_id`, `type_id`, `name`, `trading_name`, `registration_no`, `government_tax`, `email`, `logo`, `contact_number`, `website_url`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `added_by`, `created_at`) VALUES
(6, 4, 'FastAds', '-', '-', '-', 'fastads@com.ph', 'logo_1531663462.png', 0, '-', '-', '-', '-', '-', '-', 174, 1, '15-07-2018'),
(7, 4, 'Company 1', 1, 1, 1, 'company@gmail.com', 'logo_1531688796.png', 1, '-', 1, 1, 1, 1, 1, 174, 1, '16-07-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `company_info`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `company_info` (
  `company_info_id` int(111) NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) NOT NULL,
  `logo_second` varchar(255) NOT NULL,
  `sign_in_logo` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL,
  `website_url` text NOT NULL,
  `starting_year` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_email` varchar(255) NOT NULL,
  `company_contact` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`company_info_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `company_info`
		--
		INSERT INTO `company_info` (`company_info_id`, `logo`, `logo_second`, `sign_in_logo`, `favicon`, `website_url`, `starting_year`, `company_name`, `company_email`, `company_contact`, `contact_person`, `email`, `phone`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `updated_at`) VALUES
(1, 'logo_1531671144.png', 'logo2_1531671144.png', 'signin_logo_1531671151.png', 'favicon_1531671144.png', '', '', 'FastAds', '', '', 'RJ', 'info@fastads.com', 123456789, 'Address Line 1', 'Address Line 2', 'Test', '-', '-', 174, '2017-05-20 12:05:53');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `company_policy`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `company_policy` (
  `policy_id` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`policy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `company_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `company_type` (
  `type_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `company_type`
		--
		INSERT INTO `company_type` (`type_id`, `name`, `created_at`) VALUES
(1, 'Corporation', ''),
(2, 'Exempt Organization', ''),
(3, 'Partnership', ''),
(4, 'Private Foundation', ''),
(5, 'Limited Liability Company', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `contract_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `contract_type` (
  `contract_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contract_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `contract_type`
		--
		INSERT INTO `contract_type` (`contract_type_id`, `name`, `created_at`) VALUES
(1, 'Permanent', '28-04-2017'),
(2, 'Internship', '28-04-2017'),
(3, 'Regular', '28-04-2017'),
(4, 'Probation', '28-04-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `countries`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;

		--
		-- Dumping data for table `countries`
		--
		INSERT INTO `countries` (`country_id`, `country_code`, `country_name`) VALUES
(174, 'PH', 'Philippines');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `currencies`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `currencies` (
  `currency_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `symbol` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`currency_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `currencies`
		--
		INSERT INTO `currencies` (`currency_id`, `name`, `code`, `symbol`) VALUES
(1, 'Philippine Peso', 'PHP', '?'),
(2, 'Dollars', 'USD', '$'),
(6, 'Dollars', 'AUD', '$');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `database_backup`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `database_backup` (
  `backup_id` int(111) NOT NULL AUTO_INCREMENT,
  `backup_file` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`backup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `departments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(200) NOT NULL,
  `location_id` int(111) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `departments`
		--
		INSERT INTO `departments` (`department_id`, `department_name`, `location_id`, `employee_id`, `added_by`, `created_at`, `status`) VALUES
(1, 'Accounts & Finance', 3, 1, 1, '27-04-2017', 1),
(2, 'Administrator', 1, 1, 1, '28-04-2017', 1),
(3, 'Graphics &amp; Multimedia', 1, 1, 1, '28-04-2017', 1),
(4, 'Human Resource', 1, 1, 1, '28-04-2017', 1),
(5, 'Information Technology', 1, 1, 1, '28-04-2017', 1),
(6, 'Data Collection', 1, 1, 1, '28-04-2017', 1),
(7, 'Quality Assurance', 1, 1, 1, '28-04-2017', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `designations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `designations` (
  `designation_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(200) NOT NULL,
  `designation_name` varchar(200) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`designation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `designations`
		--
		INSERT INTO `designations` (`designation_id`, `department_id`, `designation_name`, `added_by`, `created_at`, `status`) VALUES
(1, 1, 'Finance Manager', 1, '10-08-2018', 1),
(2, 2, 'System Administrator', 1, '10-08-2018', 1),
(3, 4, 'Assistant Manager', 1, '10-08-2018', 1),
(4, 4, 'Manager', 1, '10-08-2018', 1),
(5, 6, 'Assistant Surveyor', 1, '10-08-2018', 1),
(6, 6, 'Surveyor', 1, '10-08-2018', 1),
(7, 5, 'Fresher PHP Developer', 1, '10-08-2018', 1),
(8, 5, 'Senior PHP Developer', 1, '10-08-2018', 1),
(9, 3, 'Graphics Designer', 1, '10-08-2018', 1),
(10, 4, 'Senior Testers', 1, '10-08-2018', 1),
(12, 5, 'Intern', 1, '10-08-2018', 1),
(13, 1, 'Finance Executive', 1, '10-08-2018', 1),
(14, 4, 'Learning Manager', 1, '10-08-2018', 1),
(15, 4, 'Learning Executive', 1, '10-08-2018', 1),
(16, 5, 'Software Engineer', 1, '10-08-2018', 1),
(17, 5, 'Manager Software Development', 1, '10-08-2018', 1),
(18, 5, 'Chief Technology Officer', 1, '10-08-2018', 1),
(19, 2, 'Chief Executive Officer', 1, '10-08-2018', 1),
(20, 3, 'President', 1, '10-08-2018', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `document_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `document_type` (
  `document_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `document_type` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`document_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `document_type`
		--
		INSERT INTO `document_type` (`document_type_id`, `document_type`, `created_at`) VALUES
(1, 'Driving License', '10-08-2018'),
(2, 'Passport', '10-08-2018'),
(3, 'Visa', '10-08-2018'),
(4, 'Resume', '19-07-2018 01:37:09'),
(5, 'Marriage Contract', '19-07-2018 01:37:18'),
(6, 'PRC License', '19-07-2018 01:37:26'),
(7, 'Drug Test', '19-07-2018 01:37:32'),
(8, 'PhilHealth Number', '19-07-2018 01:37:37'),
(9, 'Biodata', '19-07-2018 01:37:43'),
(10, 'Pagi-ibig Number', '19-07-2018 01:37:50'),
(11, 'Police Clearance', '19-07-2018 01:37:59'),
(12, 'NBI Clearance', '19-07-2018 01:38:09'),
(13, 'Transcript of Records', '19-07-2018 01:38:29'),
(14, 'Taxpayer Identification Number', '19-07-2018 01:38:35'),
(15, 'SSS Number', '19-07-2018 01:38:39'),
(16, 'Birth Certificate', '19-07-2018 01:40:18');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `email_template`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `email_template` (
  `template_id` int(111) NOT NULL AUTO_INCREMENT,
  `template_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `email_template`
		--
		INSERT INTO `email_template` (`template_id`, `template_code`, `name`, `subject`, `message`, `status`) VALUES
(1, 'test', 'Payslip generated', 'Payslip generated', '&lt;p&gt;Hello&amp;nbsp;{var employee_name},&lt;/p&gt;&lt;p&gt;Your payslip generated for the month of {var payslip_date}.&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The&amp;nbsp;{var site_name}&amp;nbsp;Team&lt;/p&gt;', 1),
(2, 'test2', 'Forgot Password', 'Forgot Password', '&lt;p&gt;There was recently a request for password for your &amp;nbsp;{var site_name}&amp;nbsp;account.&lt;/p&gt;&lt;p&gt;Please, keep it in your records so you don\&#039;t forget it.&lt;/p&gt;&lt;p&gt;Your username: {var username}&lt;br&gt;Your email address: {var email}&lt;br&gt;Your password: {var password}&lt;/p&gt;&lt;p&gt;Thank you,&lt;br&gt;The {var site_name} Team&lt;/p&gt;', 1),
(3, '', 'New Project', 'New Project', '&lt;p&gt;Dear {var name},&lt;/p&gt;&lt;p&gt;New project has been assigned to you.&lt;/p&gt;&lt;p&gt;Project Name: {var project_name}&lt;/p&gt;&lt;p&gt;Project Start Date:&amp;nbsp;&lt;span 1rem;\\\&quot;=\&quot;\&quot;&gt;{var project_start_date}&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span 1rem;\\\&quot;=\&quot;\&quot;&gt;Thank you,&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(4, '', 'Announcement', 'New Announcement', '&lt;p&gt;Dear &amp;nbsp;User,&lt;/p&gt;&lt;p&gt;New&amp;nbsp;Announcement has been published by admin,&amp;nbsp;please click on below link:&lt;/p&gt;&lt;p&gt;&lt;a href=\&quot;http://demo.workablezone.com/%7Bvar%20site_url%7D\&quot;&gt;New&amp;nbsp;Announcement...&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn\&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}&lt;/p&gt;&lt;p&gt;Have fun!&lt;br&gt;The {var site_name} Team&lt;/p&gt;', 1),
(5, '', 'Leave Request ', 'A Leave Request from you', '&lt;p&gt;Dear Admin,&lt;/p&gt;&lt;p&gt;{var employee_name}&amp;nbsp;wants a leave from you.&lt;/p&gt;&lt;p&gt;You can view this leave request by logging in to the portal using the link below.&lt;br&gt;&lt;a href=&quot;{var site_url}&quot;&gt;View Application&lt;/a&gt;&lt;br&gt;&lt;br&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(6, '', 'Leave Approve', 'Your leave request has been approved', '&lt;p&gt;Your leave request has been approved&lt;/p&gt;&lt;p&gt;&lt;font color=&quot;#333333&quot; face=&quot;sans-serif, Arial, Verdana, Trebuchet MS&quot;&gt;Congratulations!&amp;nbsp;Your leave request from&amp;nbsp;&lt;/font&gt;{var leave_start_date}&amp;nbsp;to&amp;nbsp;{var leave_end_date}&amp;nbsp;has been approved by your company management.&lt;/p&gt;&lt;p&gt;Regards&lt;br&gt;The {var site_name} Team&lt;/p&gt;', 1),
(7, '', 'Leave Reject', 'Your leave request has been Rejected', '&lt;p&gt;Your leave request has been Rejected&lt;/p&gt;&lt;p&gt;Unfortunately !&amp;nbsp;Your leave request from&amp;nbsp;{var leave_start_date}&amp;nbsp;to&amp;nbsp;{var leave_end_date}&amp;nbsp;has been Rejected by your company management.&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(8, '', 'Welcome Email ', 'Welcome Email ', '&lt;p&gt;Hello&amp;nbsp;{var employee_name},&lt;/p&gt;&lt;p&gt;Welcome to&amp;nbsp;{var site_name}&amp;nbsp;.Thanks for joining&amp;nbsp;{var site_name}. We listed your sign in details below, make sure you keep them safe.&lt;/p&gt;&lt;p&gt;Your Username: {var username}&lt;/p&gt;&lt;p&gt;Your Employee ID: {var employee_id}&lt;br&gt;Your Email Address: {var email}&lt;br&gt;Your Password: {var password}&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;{var site_url}&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}&lt;/p&gt;&lt;p&gt;Have fun!&lt;/p&gt;&lt;p&gt;The&amp;nbsp;{var site_name}&amp;nbsp;Team.&lt;/p&gt;', 1),
(9, '', 'Transfer', 'New Transfer', '&lt;p&gt;Hello&amp;nbsp;{var employee_name},&lt;/p&gt;&lt;p&gt;You have been&amp;nbsp;transfered to another department and location.&lt;/p&gt;&lt;p&gt;You can view the transfer details by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;http://demo.workablezone.com/%7Bvar%20site_url%7D&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(10, '', 'Award', 'Award Received', '&lt;p&gt;Hello&amp;nbsp;{var employee_name},&lt;/p&gt;&lt;p&gt;You have been&amp;nbsp;awarded&amp;nbsp;{var award_name}.&lt;/p&gt;&lt;p&gt;You can view this award by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;&lt;a href=\&quot;http://demo.workablezone.com/settings/email_template/%7Bvar%20site_url%7D\&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn\&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(11, '', 'New job application', 'New job application submitted', '&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;Hi,&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;&lt;strong&gt;{var employee_name}&amp;nbsp;&lt;/strong&gt;has submitted the job application for&amp;nbsp;&lt;span style=\&quot;font-weight: bolder; font-size: 1rem;\&quot;&gt;{var job_title}&lt;/span&gt;&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;&lt;span style=\&quot;font-size: 1rem;\&quot;&gt;You can view the Job Application online at:&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;&lt;span style=\&quot;font-weight: bolder; font-size: 1rem;\&quot;&gt;&lt;a href=\&quot;http://localhost/mm/ultimate_hrm/job_candidates\&quot;&gt;&lt;a href=\&quot;{var site_url}\&quot;&gt;View Job Application&lt;/a&gt;&lt;/a&gt;&lt;/span&gt;&lt;span style=\&quot;font-size: 1rem;\&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;Best Regards,&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;The {var site_name} Team&lt;/p&gt;', 1),
(12, '', 'Resignation', 'Resignation Notice', '&lt;p&gt;Hello&amp;nbsp;{var employee_name},&lt;/p&gt;&lt;p&gt;Resignation Notice has been sent to you.&lt;/p&gt;&lt;p&gt;You can view the notice details by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;{var site_url}&quot;&gt;Login Panel&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}&lt;/p&gt;&lt;p&gt;Regards&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(13, '', 'New Training', 'Training  Assigned ', '&lt;p style=&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;&quot;&gt;Dear Employee,&lt;/p&gt;&lt;p style=&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;&quot;&gt;A new Training &amp;nbsp;&lt;strong&gt;{var training_name}&lt;/strong&gt;&amp;nbsp;&amp;nbsp;has been assigned to you.&lt;/p&gt;&lt;p style=&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;&quot;&gt;You can view this Training by logging in to the portal using the link below.&lt;/p&gt;&lt;p style=&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;&quot;&gt;&lt;strong style=&quot;font-size: 1rem;&quot;&gt;&lt;a href=&quot;http://localhost/mm/ultimate_hrm/training_details.php?training_id=5&amp;amp;mode=view&quot;&gt;View Training&lt;/a&gt;&lt;/strong&gt;&lt;/p&gt;&lt;p&gt;Link doesn&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}&lt;/p&gt;&lt;p style=&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;&quot;&gt;&lt;span style=&quot;font-size: 1rem;&quot;&gt;Regards&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;&quot;&gt;&lt;span style=&quot;font-size: 1rem;&quot;&gt;The {var site_name} Team&lt;/span&gt;&lt;/p&gt;', 1),
(14, '', 'New Task', 'Task assigned', '&lt;p&gt;Dear Employee,&lt;/p&gt;&lt;p&gt;A new task&amp;nbsp;&lt;span style=&quot;font-weight: bolder;&quot;&gt;{var task_name}&lt;/span&gt;&amp;nbsp;has been assigned to you by&amp;nbsp;&lt;span style=&quot;font-weight: bolder;&quot;&gt;{var task_assigned_by}&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;You can view this task by logging in to the portal using the link below.&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;http://demo.workablezone.com/%7Bvar%20site_url%7D&quot;&gt;View Task&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Link doesn&#039;t work? Copy the following link to your browser address bar:&lt;/p&gt;&lt;p&gt;{var site_url}&lt;/p&gt;&lt;p&gt;Regards,&lt;/p&gt;&lt;p&gt;The {var site_name} Team&lt;/p&gt;', 1),
(15, '', 'New Ticket', 'New Ticket [#{var ticket_code}]', '&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;&lt;span style=\&quot;font-size: 1rem;\&quot;&gt;Dear Admin,&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;&lt;span style=\&quot;font-size: 1rem;\&quot;&gt;Your received a new ticket.&lt;/span&gt;&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;&lt;span style=\&quot;font-size: 1rem;\&quot;&gt;Ticket Code: #{var ticket_code}&lt;/span&gt;&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;Status : Open&lt;br&gt;&lt;br&gt;Click on the below link to see the ticket details and post additional comments.&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;&lt;big&gt;&lt;span style=\&quot;font-weight: bolder;\&quot;&gt;&lt;a href=\&quot;http://demo.workablezone.com/settings/email_template/%7Bvar%20site_url%7D\&quot;&gt;View Ticket&lt;/a&gt;&lt;/span&gt;&lt;/big&gt;&lt;br&gt;&lt;br&gt;Regards&lt;/p&gt;&lt;p style=\&quot;color: rgb(51, 51, 51); font-family: sans-serif, Arial, Verdana, &amp;quot;Trebuchet MS&amp;quot;;\&quot;&gt;The {var site_name} Team&lt;/p&gt;', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_bankaccount`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_bankaccount` (
  `bankaccount_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `is_primary` int(11) NOT NULL,
  `account_title` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_code` varchar(255) NOT NULL,
  `bank_branch` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`bankaccount_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_bankaccount`
		--
		INSERT INTO `employee_bankaccount` (`bankaccount_id`, `employee_id`, `is_primary`, `account_title`, `account_number`, `bank_name`, `bank_code`, `bank_branch`, `created_at`) VALUES
(1, 31, 0, 'test', 1232342, 'test bank name', 23424, 'test', '28-07-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_benefits`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_benefits` (
  `benefit_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `tin_no` varchar(255) NOT NULL,
  `sss_no` varchar(255) NOT NULL,
  `phil_no` varchar(255) NOT NULL,
  `pagibig_no` varchar(255) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`benefit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_benefits`
		--
		INSERT INTO `employee_benefits` (`benefit_id`, `employee_id`, `tin_no`, `sss_no`, `phil_no`, `pagibig_no`, `created_at`) VALUES
(1, 31, 'SSS', 123456789, '', '', '0000-00-00');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_complaints`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_complaints` (
  `complaint_id` int(111) NOT NULL AUTO_INCREMENT,
  `complaint_from` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `complaint_date` varchar(255) NOT NULL,
  `complaint_against` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_contacts`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_contacts` (
  `contact_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `is_primary` int(111) NOT NULL,
  `is_dependent` int(111) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `work_phone` varchar(255) NOT NULL,
  `work_phone_extension` varchar(255) NOT NULL,
  `mobile_phone` varchar(255) NOT NULL,
  `home_phone` varchar(255) NOT NULL,
  `work_email` varchar(255) NOT NULL,
  `personal_email` varchar(255) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_contacts`
		--
		INSERT INTO `employee_contacts` (`contact_id`, `employee_id`, `relation`, `is_primary`, `is_dependent`, `contact_name`, `work_phone`, `work_phone_extension`, `mobile_phone`, `home_phone`, `work_email`, `personal_email`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `created_at`) VALUES
(1, 31, 'Parent', 1, 0, 'a', 1, 1, 1, 1, 'test@tc.com', 'test2@tc.com', 'address', 'address2', 1, 2, 3, 174, '06-08-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_contract`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_contract` (
  `contract_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `contract_type_id` int(111) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`contract_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_contract`
		--
		INSERT INTO `employee_contract` (`contract_id`, `employee_id`, `contract_type_id`, `from_date`, `designation_id`, `title`, `to_date`, `description`, `created_at`) VALUES
(3, 1, 2, '2017-06-01', 4, 'dfdfd', '2017-06-30', 'asdfadsfsdafd', '07-06-2017'),
(4, 31, 3, '2018-07-16', 16, 'Sample Contract Titlte', '2018-07-21', '-', '16-07-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_documents`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_documents` (
  `document_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `document_type_id` int(111) NOT NULL,
  `date_of_expiry` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `notification_email` varchar(255) NOT NULL,
  `is_alert` tinyint(1) NOT NULL,
  `description` text NOT NULL,
  `document_file` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_exit`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_exit` (
  `exit_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `exit_date` varchar(255) NOT NULL,
  `exit_type_id` int(111) NOT NULL,
  `exit_interview` int(111) NOT NULL,
  `is_inactivate_account` int(111) NOT NULL,
  `reason` text NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`exit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_exit`
		--
		INSERT INTO `employee_exit` (`exit_id`, `employee_id`, `exit_date`, `exit_type_id`, `exit_interview`, `is_inactivate_account`, `reason`, `added_by`, `created_at`) VALUES
(1, 31, '2018-07-17', 2, 1, 1, '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 1, '16-07-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_exit_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_exit_type` (
  `exit_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`exit_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_exit_type`
		--
		INSERT INTO `employee_exit_type` (`exit_type_id`, `type`, `created_at`) VALUES
(1, 'Resignation', ''),
(2, 'Retirement', ''),
(3, 'End of Contract', ''),
(4, 'End of Project', ''),
(5, 'Dismissal', ''),
(6, 'Layoff', ''),
(7, 'Termination by Mutual Agreement', ''),
(8, 'Forced Resignation', ''),
(9, 'End of Temporary Appointment', ''),
(10, 'Death', ''),
(11, 'Abadonment', ''),
(12, 'Transfer', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_immigration`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_immigration` (
  `immigration_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `document_type_id` int(111) NOT NULL,
  `document_number` varchar(255) NOT NULL,
  `document_file` varchar(255) NOT NULL,
  `issue_date` varchar(255) NOT NULL,
  `expiry_date` varchar(255) NOT NULL,
  `country_id` varchar(255) NOT NULL,
  `eligible_review_date` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`immigration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_leave`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_leave` (
  `leave_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `contract_id` int(111) NOT NULL,
  `casual_leave` varchar(255) NOT NULL,
  `medical_leave` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_location`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_location` (
  `office_location_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `location_id` int(111) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`office_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_location`
		--
		INSERT INTO `employee_location` (`office_location_id`, `employee_id`, `location_id`, `from_date`, `to_date`, `created_at`) VALUES
(11, 33, 3, '2018-07-01', '2018-07-31', '20-07-2018'),
(13, 31, 3, '2018-07-01', '2018-07-31', '20-07-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_promotions`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_promotions` (
  `promotion_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `title` varchar(255) NOT NULL,
  `promotion_date` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`promotion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_qualification`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_qualification` (
  `qualification_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `name` varchar(255) NOT NULL,
  `education_level_id` int(111) NOT NULL,
  `from_year` varchar(255) NOT NULL,
  `language_id` int(111) NOT NULL,
  `to_year` varchar(255) NOT NULL,
  `skill_id` text NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`qualification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_resignations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_resignations` (
  `resignation_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `notice_date` varchar(255) NOT NULL,
  `resignation_date` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`resignation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_shift`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_shift` (
  `emp_shift_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `shift_id` int(111) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`emp_shift_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_shift`
		--
		INSERT INTO `employee_shift` (`emp_shift_id`, `employee_id`, `shift_id`, `from_date`, `to_date`, `created_at`) VALUES
(6, 1, 1, '2017-02-01', '2017-11-30', '2017-02-25 02:53:48'),
(11, 31, 1, '2018-07-16', '2018-07-31', '16-07-2018'),
(12, 34, 2, '2018-07-25', '2018-07-31', '25-07-2018'),
(13, 37, 4, '2018-07-29', '2018-08-31', '30-07-2018'),
(14, 39, 2, '2018-08-01', '2018-08-31', '07-08-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_terminations`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_terminations` (
  `termination_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `terminated_by` int(111) NOT NULL,
  `termination_type_id` int(111) NOT NULL,
  `termination_date` varchar(255) NOT NULL,
  `notice_date` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`termination_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_transfer`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_transfer` (
  `transfer_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `transfer_date` varchar(255) NOT NULL,
  `transfer_department` int(111) NOT NULL,
  `transfer_location` int(111) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(2) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employee_transfer`
		--
		INSERT INTO `employee_transfer` (`transfer_id`, `employee_id`, `transfer_date`, `transfer_department`, `transfer_location`, `description`, `status`, `added_by`, `created_at`) VALUES
(5, 31, '2018-07-16', 5, 3, '&lt;p&gt;a&lt;/p&gt;', 1, 1, '16-07-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_travels`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_travels` (
  `travel_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `visit_purpose` varchar(255) NOT NULL,
  `visit_place` varchar(255) NOT NULL,
  `travel_mode` int(111) NOT NULL,
  `arrangement_type` int(111) NOT NULL,
  `expected_budget` varchar(255) NOT NULL,
  `actual_budget` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(2) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`travel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_warnings`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_warnings` (
  `warning_id` int(111) NOT NULL AUTO_INCREMENT,
  `warning_to` int(111) NOT NULL,
  `warning_by` int(111) NOT NULL,
  `warning_date` varchar(255) NOT NULL,
  `warning_type_id` int(111) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`warning_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employee_work_experience`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employee_work_experience` (
  `work_experience_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `from_date` varchar(255) NOT NULL,
  `to_date` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`work_experience_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `employees`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `employees` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(200) NOT NULL,
  `office_shift_id` int(111) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `date_of_birth` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `age` int(5) NOT NULL,
  `user_role_id` int(100) NOT NULL,
  `department_id` int(100) NOT NULL,
  `designation_id` int(100) NOT NULL,
  `company_id` int(111) NOT NULL,
  `salary_template` varchar(255) NOT NULL,
  `hourly_grade_id` int(111) NOT NULL,
  `monthly_grade_id` int(111) NOT NULL,
  `date_of_joining` varchar(200) NOT NULL,
  `date_of_leaving` varchar(255) NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `salary` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `religions` varchar(50) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `profile_picture` text NOT NULL,
  `profile_background` text NOT NULL,
  `resume` text NOT NULL,
  `skype_id` varchar(200) NOT NULL,
  `contact_no` varchar(200) NOT NULL,
  `telephone_no` varchar(20) NOT NULL,
  `height` varchar(10) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `bloodtype` varchar(5) NOT NULL,
  `complexion` varchar(255) NOT NULL,
  `hairdescription` varchar(255) NOT NULL,
  `scar_marks` varchar(255) NOT NULL,
  `facebook_link` text NOT NULL,
  `twitter_link` text NOT NULL,
  `blogger_link` text NOT NULL,
  `linkdedin_link` text NOT NULL,
  `google_plus_link` text NOT NULL,
  `instagram_link` varchar(255) NOT NULL,
  `pinterest_link` varchar(255) NOT NULL,
  `youtube_link` varchar(255) NOT NULL,
  `tin_no` varchar(40) NOT NULL,
  `sss_no` varchar(40) NOT NULL,
  `philh_no` varchar(40) NOT NULL,
  `pagibig_no` varchar(40) NOT NULL,
  `organization` varchar(255) NOT NULL,
  `orgmem_date` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `last_login_date` varchar(255) NOT NULL,
  `last_logout_date` varchar(255) NOT NULL,
  `last_login_ip` varchar(255) NOT NULL,
  `is_logged_in` int(111) NOT NULL,
  `online` varchar(10) NOT NULL DEFAULT 'Offline',
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `employees`
		--
		INSERT INTO `employees` (`user_id`, `employee_id`, `office_shift_id`, `first_name`, `last_name`, `username`, `email`, `password`, `date_of_birth`, `gender`, `age`, `user_role_id`, `department_id`, `designation_id`, `company_id`, `salary_template`, `hourly_grade_id`, `monthly_grade_id`, `date_of_joining`, `date_of_leaving`, `marital_status`, `salary`, `address`, `religions`, `nationality`, `profile_picture`, `profile_background`, `resume`, `skype_id`, `contact_no`, `telephone_no`, `height`, `weight`, `bloodtype`, `complexion`, `hairdescription`, `scar_marks`, `facebook_link`, `twitter_link`, `blogger_link`, `linkdedin_link`, `google_plus_link`, `instagram_link`, `pinterest_link`, `youtube_link`, `tin_no`, `sss_no`, `philh_no`, `pagibig_no`, `organization`, `orgmem_date`, `is_active`, `last_login_date`, `last_logout_date`, `last_login_ip`, `is_logged_in`, `online`, `created_at`) VALUES
(1, 'RJBG02', 1, 'RJ', 'Gonato', 'admin', 'admin@testemail.com', 'Programm3r1', '10/04/2016', 'Male', 10, 1, 5, 18, 1, 'monthly', 0, 1, '2016-10-16', '', 'Single', '', '-', 'L', 'O', '', 'profile_background_1499896596.jpg', '', '', 12344, 0, 1, 2, 'O', 'H', 'E', 'L', '', '', '', '', '', '', '', '', 11, 22, 33, 44, 'Test', '2000-08-01', 1, '08-08-2018 18:52:40', '08-08-2018 18:52:38', '::1', 1, 'Online', '15-06-2017'),
(31, 'JC2018', 1, 'Juan', 'Cruz', 'juancruz', 'juancruz@gmail.com', 'password', '2018-07-15', 'Others', 20, 9, 5, 16, 1, 'monthly', 0, 1, '2018-07-15', '', 'Single', '', 'juancruz address', 'Hello world', 'Filipino', 'profile_1532017722.jpg', 'profile_background_1531600908.png', '', '', 12345689, 4564241111, 1.90, 2.00, 'O', 'test', 'tesgt1', 'tessd', 'test', '', '', '', '', '', '', '', 0, 0, 0, 0, 'test1', '0000-00-10', 1, '06-08-2018 09:46:05', '06-08-2018 10:01:18', '::1', 0, 'Offline', '14-07-2018'),
(32, 'EMP101', 1, 'Employee', 'One', 'empone', 'emp@gmail.com', 'password', '1992-07-15', 'Male', 0, 9, 3, 9, 1, '', 0, 0, '2018-07-19', '', 'Single', '', 'address employee', 'Test lng', '', 'profile_1532017528.png', '', '', '', 0000001000, '1000-11', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', 0, '25-07-2018 16:31:10', '25-07-2018 16:31:36', '::1', 0, 'Offline', '19-07-2018'),
(33, 'JEX2018', 1, 'Juana', 'ex', 'juanaex', 'juanaex@gmail.com', 'password', '1991-07-18', 'Female', 0, 9, 4, 3, 1, '', 0, 0, '2018-07-20', '', 'Single', '', 'juanaex address here..', '', '', 'profile_1532016163.png', '', '', '', 000000000, '57-7657', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', 0, '', '', '', 0, 'Offline', '20-07-2018'),
(34, 'EMP202', 1, 'Employee', 'Two', 'empnumber2', 'empnumber2@gmail.com', 'password', '2018-07-20', 'Male', 0, 9, 4, 10, 0, '', 0, 0, '2018-07-20', '', 'Single', '', 'empnumber2 address', '', '', '', '', '', '', 00010100101, 4646666, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', 0, '25-07-2018 20:53:03', '25-07-2018 20:53:15', '::1', 0, 'Offline', '20-07-2018'),
(36, 'EMP03', 1, 'Employee', 'Three', 'emp03', 'emp03@gmail.com', 'password', '1992-07-22', 'Male', 0, 9, 3, 9, 0, '', 0, 0, '2018-07-28', '', 'Single', '', 'emp 3 address', '', '', '', '', '', '', 0231231, '35-3554', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', 0, '', '', '', 0, 'Offline', '28-07-2018'),
(37, 'TEST01', 1, 'Test', 'admin', 'testadmin', 'testadmin@gmail.com', 'password', '2018-07-29', 'Female', 0, 0, 4, 4, 0, '', 0, 0, '2018-07-29', '', 'Single', '', 'test', '', '', '', '', '', '', 011111, '23-234234', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', 1, '07-08-2018 16:43:39', '07-08-2018 16:56:56', '::1', 0, 'Offline', '29-07-2018'),
(38, 'EMP04', 1, 'Employee ', 'Four', 'emp04', 'emp04@gmail.com', 'password', '1992-08-13', 'Male', 25, 9, 3, 9, 0, '', 0, 0, '2018-08-02', '', 'Single', '', 'adadadad', 'Hello', 'Hello', '', '', '', '', 092424234242, '032-3234234', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', 0, '', '', '', 0, 'Offline', '02-08-2018'),
(39, 'HELLo', 1, 'HELLo', 'HELLo', 'HELLo', 'HELLo@gmail.com', 'password', '2018-08-09', 'Male', 0, 9, 5, 8, 0, '', 0, 0, '2018-08-02', '', 'Single', '', 'HELLo', '', '', '', '', '', '', 23423, 234234, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'test', '2018-08-14', 1, '08-08-2018 11:27:17', '08-08-2018 11:27:53', '::1', 0, 'Offline', '02-08-2018'),
(40, 'TSET1', 1, 'Tset', 'Tset', 'Tset', 'Tset@gmail.com', 'Tset12345', '', 'Male', 0, 9, 6, 6, 0, '', 0, 0, '2018-08-07', '', 'Single', '', 'Tset', '', '', '', '', '', '', 34234, 423423, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', '', 0, 'Offline', '07-08-2018');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `expense_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `expense_type` (
  `expense_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `expense_type`
		--
		INSERT INTO `expense_type` (`expense_type_id`, `name`, `status`, `created_at`) VALUES
(1, 'Utilities', 1, '2017-04-27 08:52:10'),
(2, 'Rent', 1, '2017-04-28 07:46:18'),
(3, 'Insurance', 1, '2017-04-28 07:46:23'),
(5, 'Supplies', 1, '2017-04-28 07:46:34'),
(7, 'Wages', 1, '2017-04-28 07:47:09'),
(8, 'Taxes', 1, '2017-04-28 08:03:29'),
(9, 'Interest', 1, '2017-04-28 08:03:35'),
(10, 'Maintenance', 1, '2017-04-28 08:03:46'),
(11, 'Meals and Entertainment', 1, '2017-04-28 08:03:53');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `expenses`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `expenses` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(200) NOT NULL,
  `expense_type_id` int(200) NOT NULL,
  `billcopy_file` text NOT NULL,
  `amount` varchar(200) NOT NULL,
  `purchase_date` varchar(200) NOT NULL,
  `remarks` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `status_remarks` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `holidays`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `holidays` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `is_publish` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `holidays`
		--
		INSERT INTO `holidays` (`holiday_id`, `event_name`, `description`, `start_date`, `end_date`, `is_publish`, `created_at`) VALUES
(1, 'National Holidays', '&lt;p&gt;National Holidays&lt;br&gt;&lt;/p&gt;', '2017-06-08', '2017-06-09', 1, '28-04-2017'),
(2, 'Festival', '<span style="color: rgb(79, 81, 84); font-family: "Open Sans", Arial;">Festival</span>', '2017-04-13', '2017-04-14', 1, '28-04-2017'),
(3, 'Test', '&lt;p&gt;this is a tests&lt;/p&gt;', '2018-07-22', '2018-07-23', 1, '2018-07-22');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `hourly_templates`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `hourly_templates` (
  `hourly_rate_id` int(111) NOT NULL AUTO_INCREMENT,
  `hourly_grade` varchar(255) NOT NULL,
  `hourly_rate` varchar(255) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`hourly_rate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `hourly_templates`
		--
		INSERT INTO `hourly_templates` (`hourly_rate_id`, `hourly_grade`, `hourly_rate`, `added_by`, `created_at`) VALUES
(1, 'Hourly Wage Title-1', 15, 1, '2017-04-28 04:15:10'),
(2, 'Hourly Wage Title-2', 20, 1, '2017-04-28 04:15:16'),
(3, 'Hourly Wage Title-3', 25, 1, '2017-04-28 04:15:21'),
(4, 'Hourly Wage Title-4', 30, 1, '2017-04-28 04:15:28'),
(5, 'Hourly Wage Title-5', 35, 1, '2017-04-28 04:15:35'),
(6, 'Hourly Wage Title-6', 40, 1, '2017-04-28 04:15:42'),
(7, 'Hourly Wage Title-7', 45, 1, '2017-04-28 04:15:50'),
(8, 'Hourly Wage Title-8', 50, 1, '2017-04-28 04:15:55');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `job_applications`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `job_applications` (
  `application_id` int(111) NOT NULL AUTO_INCREMENT,
  `job_id` int(111) NOT NULL,
  `user_id` int(111) NOT NULL,
  `message` text NOT NULL,
  `job_resume` text NOT NULL,
  `application_status` varchar(200) NOT NULL,
  `application_remarks` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `job_interviews`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `job_interviews` (
  `job_interview_id` int(111) NOT NULL AUTO_INCREMENT,
  `job_id` int(111) NOT NULL,
  `interviewers_id` varchar(255) NOT NULL,
  `interview_place` varchar(255) NOT NULL,
  `interview_date` varchar(255) NOT NULL,
  `interview_time` varchar(255) NOT NULL,
  `interviewees_id` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_interview_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `job_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `job_type` (
  `job_type_id` int(111) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `job_type`
		--
		INSERT INTO `job_type` (`job_type_id`, `type`, `created_at`) VALUES
(1, 'Intern', ''),
(2, 'Freelancer', ''),
(5, 'Full-Time', '2017-03-22 07:07:55'),
(6, 'Part-Time', '2017-03-22 07:08:00'),
(7, 'Contract', '2017-03-22 07:08:03');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `jobs`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `jobs` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_title` varchar(255) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `job_type` int(225) NOT NULL,
  `job_vacancy` int(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `minimum_experience` varchar(255) NOT NULL,
  `date_of_closing` varchar(200) NOT NULL,
  `short_description` text NOT NULL,
  `long_description` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `jobs`
		--
		INSERT INTO `jobs` (`job_id`, `job_title`, `designation_id`, `job_type`, `job_vacancy`, `gender`, `minimum_experience`, `date_of_closing`, `short_description`, `long_description`, `status`, `created_at`) VALUES
(1, 'Software Engineer', 16, 2, 2, 'No Preference', '4 Years', '2017-06-01', 'At least 3 years of work experience as Software Engineer in a reputable company / organization', 'At least 3 years of work experience as Software Engineer in a reputable company / organization.&lt;p&gt;&lt;/p&gt;', 1, '2017-04-28 04:32:07'),
(2, 'Web Developer', 8, 5, 3, 'Female', '3 Years', '2017-06-07', 'We are looking for a Web Developer with strong proficiency in Node.js, responsible for managing the interchange of data between the server and the clients. ', '&lt;p&gt;&lt;span style=\&quot;font-size: 14px;\&quot;&gt;&lt;span style=\&quot;color: rgb(66, 66, 66); font-family: \&quot; source=\&quot;\&quot; sans=\&quot;\&quot; pro\&quot;;=\&quot;\&quot; font-size:=\&quot;\&quot; 14px;\&quot;=\&quot;\&quot;&gt;We are looking for a Web Developer with strong proficiency in Node.js, responsible for managing the interchange of data between the server and the clients. Your primary focus will be the development of all server-side logic, definition and maintenance of the central database, and ensuring high performance and responsiveness to requests from the front-end (web, phone, tablet apps). You will also be responsible for implementing the web based front-end, so familiarity with front-end technologies is important.&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;color: rgb(66, 66, 66); font-weight: bold; font-size: 14px;\&quot;&gt;Responsibilities:&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;font-size: 14px;\&quot;&gt;&lt;span style=\&quot;color: rgb(66, 66, 66);\&quot;&gt;Design and implementation of low-latency, high-availability, and high-performance applications&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;font-size: 14px;\&quot;&gt;&lt;span style=\&quot;color: rgb(66, 66, 66);\&quot;&gt;Integration of user-facing elements developed with server side logic. User facing elements include web, phone and tablet apps&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;font-size: 14px;\&quot;&gt;&lt;span style=\&quot;color: rgb(66, 66, 66);\&quot;&gt;Design and implementation of user-facing web applications&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;color: rgb(66, 66, 66); font-size: 14px;\&quot;&gt;Writing reusable, testable, and efficient code&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;color: rgb(66, 66, 66); font-size: 14px;\&quot;&gt;Writing exhaustive automated tests to regress the server side using nightly automated runs (Jenkins CI)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;font-size: 14px;\&quot;&gt;&lt;span style=\&quot;color: rgb(66, 66, 66);\&quot;&gt;Implementation of security and data protection&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;font-size: 14px;\&quot;&gt;&lt;span style=\&quot;color: rgb(66, 66, 66);\&quot;&gt;Integration of data storage solutions&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=\&quot;color: rgb(66, 66, 66); font-size: 14px;\&quot;&gt;Integration of high-availability solutions at web and database level&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1, '2017-04-28 04:36:17'),
(3, 'Front End Web Developer', 16, 5, 4, 'Male', '4 Years', '2017-08-02', 'We are looking for a ambitious and multi-faceted web/front-end developer. You won\\\\\\\\\\\\\\\&#039;t just be writing snippets of code. Your knowledge of HTML, CSS, JS, JQuery and other languages will equip you with the aility to write big amounts of inter-related code in a clean modular way.', 'We are looking for a ambitious and multi-faceted web/front-end developer. You won\\\\\\\\\\\\\\\&#039;t just be writing snippets of code. Your knowledge of HTML, CSS, JS, JQuery and other languages will equip you with the aility to write big amounts of inter-related code in a clean modular way.&lt;p&gt;&lt;/p&gt;', 1, '2017-04-28 04:43:47'),
(4, 'General Manager', 4, 2, 4, 'Female', '4 Years', '2017-07-06', 'The incumbent will be responsible for updating and implementing Organizationâ€™s Innovation strategy, steering the Innovation initiatives and overseeing the Knowledge Management function of the organization.', 'The incumbent will be responsible for updating and implementing Organizationâ€™s Innovation strategy, steering the Innovation initiatives and overseeing the Knowledge Management function of the organization.&lt;p&gt;&lt;/p&gt;', 1, '2017-04-28 04:52:21');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `leave_applications`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `leave_applications` (
  `leave_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(222) NOT NULL,
  `leave_type_id` int(222) NOT NULL,
  `from_date` varchar(200) NOT NULL,
  `to_date` varchar(200) NOT NULL,
  `applied_on` varchar(200) NOT NULL,
  `reason` text NOT NULL,
  `remarks` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `leave_applications`
		--
		INSERT INTO `leave_applications` (`leave_id`, `employee_id`, `leave_type_id`, `from_date`, `to_date`, `applied_on`, `reason`, `remarks`, `status`, `created_at`) VALUES
(1, 32, 2, '2018-07-25', '2018-07-26', '2018-07-25 04:30:29', 'Test', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 1, '2018-07-25 04:30:29'),
(2, 39, 2, '2018-08-08', '2018-08-09', '2018-08-08 11:27:02', 'kknkn', '&lt;p&gt;nbb&lt;/p&gt;', 1, '2018-08-08 11:27:02');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `leave_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `leave_type` (
  `leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `days_per_year` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `leave_type`
		--
		INSERT INTO `leave_type` (`leave_type_id`, `type_name`, `days_per_year`, `status`, `created_at`) VALUES
(1, 'Casual Leave', 15, 1, '2017-04-28 07:42:15'),
(2, 'Medical Leave', 20, 1, '2017-04-28 07:42:24');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `make_payment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `make_payment` (
  `make_payment_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `department_id` int(111) NOT NULL,
  `company_id` int(111) NOT NULL,
  `location_id` int(111) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `payment_date` varchar(200) NOT NULL,
  `basic_salary` varchar(255) NOT NULL,
  `payment_amount` varchar(255) NOT NULL,
  `gross_salary` varchar(255) NOT NULL,
  `total_allowances` varchar(255) NOT NULL,
  `total_deductions` varchar(255) NOT NULL,
  `net_salary` varchar(255) NOT NULL,
  `house_rent_allowance` varchar(255) NOT NULL,
  `medical_allowance` varchar(255) NOT NULL,
  `travelling_allowance` varchar(255) NOT NULL,
  `dearness_allowance` varchar(255) NOT NULL,
  `provident_fund` varchar(255) NOT NULL,
  `tax_deduction` varchar(255) NOT NULL,
  `security_deposit` varchar(255) NOT NULL,
  `overtime_rate` varchar(255) NOT NULL,
  `is_payment` tinyint(1) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `hourly_rate` varchar(255) NOT NULL,
  `total_hours_work` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`make_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `office_location`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `office_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(111) NOT NULL,
  `location_head` int(111) NOT NULL,
  `location_manager` int(111) NOT NULL,
  `location_name` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `address_1` text NOT NULL,
  `address_2` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `country` int(111) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `office_location`
		--
		INSERT INTO `office_location` (`location_id`, `company_id`, `location_head`, `location_manager`, `location_name`, `email`, `phone`, `fax`, `address_1`, `address_2`, `city`, `state`, `zipcode`, `country`, `added_by`, `created_at`, `status`) VALUES
(1, 6, 1, 1, 'FastAds Office', 'admin@demo.com', 123654, 1, 'Address Line 1', 'Address Line 2', 'Cebu', 'Cebu', 1, 174, 1, '27-04-2017', 1),
(3, 7, 1, 1, 'Location 1', 'company@location1.com', 1, 1, 1, 1, 'Cebu', 1, 1, 174, 1, '16-07-2018', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `office_shift`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `office_shift` (
  `office_shift_id` int(111) NOT NULL AUTO_INCREMENT,
  `shift_name` varchar(255) NOT NULL,
  `default_shift` int(111) NOT NULL,
  `monday_in_time` varchar(222) NOT NULL,
  `monday_out_time` varchar(222) NOT NULL,
  `tuesday_in_time` varchar(222) NOT NULL,
  `tuesday_out_time` varchar(222) NOT NULL,
  `wednesday_in_time` varchar(222) NOT NULL,
  `wednesday_out_time` varchar(222) NOT NULL,
  `thursday_in_time` varchar(222) NOT NULL,
  `thursday_out_time` varchar(222) NOT NULL,
  `friday_in_time` varchar(222) NOT NULL,
  `friday_out_time` varchar(222) NOT NULL,
  `saturday_in_time` varchar(222) NOT NULL,
  `saturday_out_time` varchar(222) NOT NULL,
  `sunday_in_time` varchar(222) NOT NULL,
  `sunday_out_time` varchar(222) NOT NULL,
  `created_at` varchar(222) NOT NULL,
  PRIMARY KEY (`office_shift_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `office_shift`
		--
		INSERT INTO `office_shift` (`office_shift_id`, `shift_name`, `default_shift`, `monday_in_time`, `monday_out_time`, `tuesday_in_time`, `tuesday_out_time`, `wednesday_in_time`, `wednesday_out_time`, `thursday_in_time`, `thursday_out_time`, `friday_in_time`, `friday_out_time`, `saturday_in_time`, `saturday_out_time`, `sunday_in_time`, `sunday_out_time`, `created_at`) VALUES
(1, 'Morning Shift', 0, '09:00', '17:00', '09:00', '17:00', '09:00', '17:00', '09:00', '17:00', '09:00', '17:00', '10:00', '15:00', '', '', '2017-04-28'),
(2, 'Afternoon Shift', 0, '15:00', '23:00', '15:00', '23:00', '15:00', '23:00', '15:00', '23:00', '15:00', '23:00', '15:00', '21:00', '', '', '2017-04-28'),
(4, 'Night Shift', 0, '18:00', '02:00', '18:00', '02:00', '18:00', '02:00', '18:58', '02:00', '18:00', '02:00', '18:00', '00:00', '', '', '2017-04-28');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `payment_method`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `payment_method` (
  `payment_method_id` int(111) NOT NULL AUTO_INCREMENT,
  `method_name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`payment_method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `payment_method`
		--
		INSERT INTO `payment_method` (`payment_method_id`, `method_name`, `created_at`) VALUES
(10, 'Cash', '24-02-2017'),
(11, 'Credit Card', '24-02-2017'),
(12, 'Bank', '24-02-2017'),
(13, 'Visa Debit Cart', '24-02-2017'),
(14, 'Online', '24-02-2017'),
(15, 'By Hand', '24-02-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `performance_appraisal`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `performance_appraisal` (
  `performance_appraisal_id` int(111) NOT NULL AUTO_INCREMENT,
  `employee_id` int(111) NOT NULL,
  `appraisal_year_month` varchar(255) NOT NULL,
  `customer_experience` int(111) NOT NULL,
  `marketing` int(111) NOT NULL,
  `management` int(111) NOT NULL,
  `administration` int(111) NOT NULL,
  `presentation_skill` int(111) NOT NULL,
  `quality_of_work` int(111) NOT NULL,
  `efficiency` int(111) NOT NULL,
  `integrity` int(111) NOT NULL,
  `professionalism` int(111) NOT NULL,
  `team_work` int(111) NOT NULL,
  `critical_thinking` int(111) NOT NULL,
  `conflict_management` int(111) NOT NULL,
  `attendance` int(111) NOT NULL,
  `ability_to_meet_deadline` int(111) NOT NULL,
  `remarks` text NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`performance_appraisal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `performance_appraisal`
		--
		INSERT INTO `performance_appraisal` (`performance_appraisal_id`, `employee_id`, `appraisal_year_month`, `customer_experience`, `marketing`, `management`, `administration`, `presentation_skill`, `quality_of_work`, `efficiency`, `integrity`, `professionalism`, `team_work`, `critical_thinking`, `conflict_management`, `attendance`, `ability_to_meet_deadline`, `remarks`, `added_by`, `created_at`) VALUES
(2, 1, '1972-07', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '&lt;p&gt;sdfdfdsf&lt;/p&gt;', 1, '10-07-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `performance_indicator`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `performance_indicator` (
  `performance_indicator_id` int(111) NOT NULL AUTO_INCREMENT,
  `designation_id` int(111) NOT NULL,
  `customer_experience` int(111) NOT NULL,
  `marketing` int(111) NOT NULL,
  `management` int(111) NOT NULL,
  `administration` int(111) NOT NULL,
  `presentation_skill` int(111) NOT NULL,
  `quality_of_work` int(111) NOT NULL,
  `efficiency` int(111) NOT NULL,
  `integrity` int(111) NOT NULL,
  `professionalism` int(111) NOT NULL,
  `team_work` int(111) NOT NULL,
  `critical_thinking` int(111) NOT NULL,
  `conflict_management` int(111) NOT NULL,
  `attendance` int(111) NOT NULL,
  `ability_to_meet_deadline` int(111) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`performance_indicator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `performance_indicator`
		--
		INSERT INTO `performance_indicator` (`performance_indicator_id`, `designation_id`, `customer_experience`, `marketing`, `management`, `administration`, `presentation_skill`, `quality_of_work`, `efficiency`, `integrity`, `professionalism`, `team_work`, `critical_thinking`, `conflict_management`, `attendance`, `ability_to_meet_deadline`, `added_by`, `created_at`) VALUES
(1, 15, 0, 3, 2, 3, 3, 3, 2, 2, 3, 2, 2, 3, 3, 3, 1, '28-04-2017'),
(3, 2, 2, 1, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 1, '01-06-2017'),
(5, 2, 1, 3, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 1, '03-07-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `projects`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `projects` (
  `project_id` int(111) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  `company_id` int(111) NOT NULL,
  `assigned_to` text NOT NULL,
  `priority` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `description` text NOT NULL,
  `added_by` int(111) NOT NULL,
  `project_progress` varchar(255) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `projects`
		--
		INSERT INTO `projects` (`project_id`, `title`, `client_name`, `start_date`, `end_date`, `company_id`, `assigned_to`, `priority`, `summary`, `description`, `added_by`, `project_progress`, `status`, `created_at`) VALUES
(1, 'Wz Job Portal', 'Wz Inc.', '2017-07-01', '2017-07-01', 4, '24,27,28,29', 2, 'One morning, when Gregor Samsa woke from troubled..', 'asdfadsfdsfd', 1, 47, 1, '28-04-2017'),
(2, 'Magento Project', 'George Turner', '2017-02-01', '2017-08-25', 4, 23, 2, 'One morning, when Gregor Samsa woke from troubled..', '&lt;p&gt;Magento Project Descritpion here..&lt;br&gt;&lt;/p&gt;', 1, 30, 1, '29-04-2017'),
(3, 'Magento-2 Module', 'Thomas Foster', '2017-04-04', '2017-06-07', 4, 23, 3, 'A collection of textile samples lay spread out on the table..', '&lt;p&gt;Magento-2 Module&lt;/p&gt;', 1, 45, 1, '29-04-2017'),
(4, 'Magento Price Offer Module', 'David Jones', '2017-05-01', '2017-10-19', 4, 23, 1, 'That he had recently cut out of an illustrated magazine..', '&lt;p&gt;test description&lt;/p&gt;', 1, 75, 1, '20-05-2017'),
(5, 'Login Errors', 'John Smiths', '2017-02-02', '2017-11-08', 4, 23, 2, 'You''ve got to get enough sleep. Other travelling salesmen..', 'sdfadfadff&lt;p&gt;&lt;/p&gt;', 1, 37, 1, '20-05-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `qualification_education_level`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `qualification_education_level` (
  `education_level_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`education_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `qualification_education_level`
		--
		INSERT INTO `qualification_education_level` (`education_level_id`, `name`, `created_at`) VALUES
(1, 'High School Diploma / GED', '28-04-2017'),
(2, 'Associate Degree', '28-04-2017'),
(3, 'Graduate', '28-04-2017'),
(4, 'Post Graduate', '28-04-2017'),
(5, 'Doctorate', '28-04-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `qualification_language`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `qualification_language` (
  `language_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `qualification_language`
		--
		INSERT INTO `qualification_language` (`language_id`, `name`, `created_at`) VALUES
(1, 'English', '28-04-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `qualification_skill`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `qualification_skill` (
  `skill_id` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`skill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `qualification_skill`
		--
		INSERT INTO `qualification_skill` (`skill_id`, `name`, `created_at`) VALUES
(1, 'PHP 4/5/6/7', '28-04-2017'),
(2, 'jQuery', '28-04-2017'),
(3, 'Ajax', '28-04-2017'),
(4, 'Magento', '28-04-2017'),
(5, 'CodeIgniter', '28-04-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `salary_templates`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `salary_templates` (
  `salary_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_grades` varchar(255) NOT NULL,
  `basic_salary` varchar(255) NOT NULL,
  `overtime_rate` varchar(255) NOT NULL,
  `house_rent_allowance` varchar(255) NOT NULL,
  `medical_allowance` varchar(255) NOT NULL,
  `travelling_allowance` varchar(255) NOT NULL,
  `dearness_allowance` varchar(255) NOT NULL,
  `security_deposit` varchar(255) NOT NULL,
  `provident_fund` varchar(255) NOT NULL,
  `tax_deduction` varchar(255) NOT NULL,
  `gross_salary` varchar(255) NOT NULL,
  `total_allowance` varchar(255) NOT NULL,
  `total_deduction` varchar(255) NOT NULL,
  `net_salary` varchar(255) NOT NULL,
  `added_by` int(111) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`salary_template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `salary_templates`
		--
		INSERT INTO `salary_templates` (`salary_template_id`, `salary_grades`, `basic_salary`, `overtime_rate`, `house_rent_allowance`, `medical_allowance`, `travelling_allowance`, `dearness_allowance`, `security_deposit`, `provident_fund`, `tax_deduction`, `gross_salary`, `total_allowance`, `total_deduction`, `net_salary`, `added_by`, `created_at`) VALUES
(1, 'Payroll Template-1', 1201, '', 50, 50, 50, 55, 20, 20, 10, 1406, 205, 50, 1356, 1, '2017-04-28 04:13:40'),
(2, 'Payroll Template-2', 2000, '', 80, 80, '', '', 50, '', 20, 2160, 160, 70, 2090, 1, '2017-04-28 04:14:00'),
(3, 'Payroll Template-3', 2500, '', 100, 80, 70, '', 40, 15, 55, 2750, 250, 110, 2640, 1, '2017-04-28 04:14:29'),
(4, 'Payroll Template-4', 2500, 15, 70, 70, 70, 60, 18, 12, 15, 2770, 270, 45, 2725, 1, '2017-04-28 04:14:56');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `support_ticket_files`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `support_ticket_files` (
  `ticket_file_id` int(111) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(111) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `ticket_files` varchar(255) NOT NULL,
  `file_size` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`ticket_file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `support_tickets`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `support_tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_code` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `employee_id` int(111) NOT NULL,
  `ticket_priority` varchar(255) NOT NULL,
  `department_id` int(111) NOT NULL,
  `assigned_to` text NOT NULL,
  `message` text NOT NULL,
  `description` text NOT NULL,
  `ticket_remarks` text NOT NULL,
  `ticket_status` varchar(200) NOT NULL,
  `ticket_note` text NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `support_tickets`
		--
		INSERT INTO `support_tickets` (`ticket_id`, `ticket_code`, `subject`, `employee_id`, `ticket_priority`, `department_id`, `assigned_to`, `message`, `description`, `ticket_remarks`, `ticket_status`, `ticket_note`, `created_at`) VALUES
(1, 'ZXDMUDH', 'Test Ticket', 23, 2, 0, '1,23,27', '', '<p>Test Ticket Description</p>', 'testtttt', 1, 'asddddasdfdfe', '2017-04-27 09:05:47'),
(2, 'VH4BKR9', 'New Project', 23, 2, 0, 24, '', '&lt;p&gt;asd&lt;/p&gt;', '', 1, '', '2017-05-05 05:17:43');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `system_setting`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `system_setting` (
  `setting_id` int(111) NOT NULL AUTO_INCREMENT,
  `application_name` varchar(255) NOT NULL,
  `default_currency` varchar(255) NOT NULL,
  `default_currency_symbol` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `show_currency` varchar(255) NOT NULL,
  `currency_position` varchar(255) NOT NULL,
  `notification_position` varchar(255) NOT NULL,
  `notification_close_btn` varchar(255) NOT NULL,
  `notification_bar` varchar(255) NOT NULL,
  `enable_registration` varchar(255) NOT NULL,
  `login_with` varchar(255) NOT NULL,
  `date_format_xi` varchar(255) NOT NULL,
  `employee_manage_own_contact` varchar(255) NOT NULL,
  `employee_manage_own_profile` varchar(255) NOT NULL,
  `employee_manage_own_qualification` varchar(255) NOT NULL,
  `employee_manage_own_work_experience` varchar(255) NOT NULL,
  `employee_manage_own_document` varchar(255) NOT NULL,
  `employee_manage_own_picture` varchar(255) NOT NULL,
  `employee_manage_own_social` varchar(255) NOT NULL,
  `employee_manage_own_bank_account` varchar(255) NOT NULL,
  `enable_attendance` varchar(255) NOT NULL,
  `enable_clock_in_btn` varchar(255) NOT NULL,
  `enable_email_notification` varchar(255) NOT NULL,
  `payroll_include_day_summary` varchar(255) NOT NULL,
  `payroll_include_hour_summary` varchar(255) NOT NULL,
  `payroll_include_leave_summary` varchar(255) NOT NULL,
  `enable_job_application_candidates` varchar(255) NOT NULL,
  `job_logo` varchar(255) NOT NULL,
  `payroll_logo` varchar(255) NOT NULL,
  `enable_profile_background` varchar(255) NOT NULL,
  `enable_policy_link` varchar(255) NOT NULL,
  `enable_layout` varchar(255) NOT NULL,
  `job_application_format` text NOT NULL,
  `project_email` varchar(255) NOT NULL,
  `holiday_email` varchar(255) NOT NULL,
  `leave_email` varchar(255) NOT NULL,
  `payslip_email` varchar(255) NOT NULL,
  `award_email` varchar(255) NOT NULL,
  `recruitment_email` varchar(255) NOT NULL,
  `announcement_email` varchar(255) NOT NULL,
  `training_email` varchar(255) NOT NULL,
  `task_email` varchar(255) NOT NULL,
  `compact_sidebar` varchar(255) NOT NULL,
  `fixed_header` varchar(255) NOT NULL,
  `fixed_sidebar` varchar(255) NOT NULL,
  `boxed_wrapper` varchar(255) NOT NULL,
  `layout_static` varchar(255) NOT NULL,
  `system_skin` varchar(255) NOT NULL,
  `animation_effect` varchar(255) NOT NULL,
  `animation_effect_modal` varchar(255) NOT NULL,
  `animation_effect_topmenu` varchar(255) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `enable_page_rendered` varchar(255) NOT NULL,
  `enable_current_year` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `system_setting`
		--
		INSERT INTO `system_setting` (`setting_id`, `application_name`, `default_currency`, `default_currency_symbol`, `show_currency`, `currency_position`, `notification_position`, `notification_close_btn`, `notification_bar`, `enable_registration`, `login_with`, `date_format_xi`, `employee_manage_own_contact`, `employee_manage_own_profile`, `employee_manage_own_qualification`, `employee_manage_own_work_experience`, `employee_manage_own_document`, `employee_manage_own_picture`, `employee_manage_own_social`, `employee_manage_own_bank_account`, `enable_attendance`, `enable_clock_in_btn`, `enable_email_notification`, `payroll_include_day_summary`, `payroll_include_hour_summary`, `payroll_include_leave_summary`, `enable_job_application_candidates`, `job_logo`, `payroll_logo`, `enable_profile_background`, `enable_policy_link`, `enable_layout`, `job_application_format`, `project_email`, `holiday_email`, `leave_email`, `payslip_email`, `award_email`, `recruitment_email`, `announcement_email`, `training_email`, `task_email`, `compact_sidebar`, `fixed_header`, `fixed_sidebar`, `boxed_wrapper`, `layout_static`, `system_skin`, `animation_effect`, `animation_effect_modal`, `animation_effect_topmenu`, `footer_text`, `enable_page_rendered`, `enable_current_year`, `updated_at`) VALUES
(1, 'Graphene SME', 'PHP - ?', 'PHP - ?', 'symbol', 'Prefix', 'toast-bottom-right', 'true', 'false', 'no', 'username', 'M-d-Y', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', '', 'yes', 'yes', 'yes', 'yes', 'job_logo_1531674498.png', 'payroll_logo_1531674448.png', 'yes', 'yes', 'yes', 'doc,docx,jpeg,jpg,pdf,txt,excel', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', '', 'fixed-header', 'fixed-sidebar', '', '', 'skin-3', 'fadeInDown', 'fadeIn', 'fadeIn', 'Graphene SME v1.88180', 'yes', 'yes', '2017-05-09 04:27:32');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `tasks`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` int(111) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `assigned_to` varchar(255) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `end_date` varchar(200) NOT NULL,
  `task_hour` varchar(200) NOT NULL,
  `task_progress` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `task_status` int(5) NOT NULL,
  `task_note` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `tasks`
		--
		INSERT INTO `tasks` (`task_id`, `created_by`, `task_name`, `assigned_to`, `start_date`, `end_date`, `task_hour`, `task_progress`, `description`, `task_status`, `task_note`, `created_at`) VALUES
(1, 1, 'Magento Small Changes', '1,23,29', '2017-04-01', '2017-04-10', 12, 51, '&lt;p&gt;Test task description.&lt;/p&gt;', 1, 'dfgsfdgfdfdafad3', '27-04-2017'),
(2, 1, 'Magento Grid view', '1,23,24', '2017-05-01', '2017-05-31', 25, 59, '&lt;p&gt;test description&lt;/p&gt;', 1, '', '20-05-2017'),
(3, 1, 'Js Error', '23,24,29', '2017-03-01', '2017-05-31', 24, 83, '&lt;p&gt;test description&lt;/p&gt;', 1, '', '20-05-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `tasks_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `tasks_attachment` (
  `task_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(200) NOT NULL,
  `upload_by` int(255) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` text NOT NULL,
  `attachment_file` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`task_attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `tasks_attachment`
		--
		INSERT INTO `tasks_attachment` (`task_attachment_id`, `task_id`, `upload_by`, `file_title`, `file_description`, `attachment_file`, `created_at`) VALUES
(5, 3, 23, 'sdfadsf', 'testttt', 'task_1498296035.jpg', '24-06-2017 11:20:35');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `tasks_comments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `tasks_comments` (
  `comment_id` int(11) NOT NULL,
  `task_id` int(200) NOT NULL,
  `user_id` int(200) NOT NULL,
  `task_comments` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `tasks_comments`
		--
		INSERT INTO `tasks_comments` (`comment_id`, `task_id`, `user_id`, `task_comments`, `created_at`) VALUES
(3, 1, 23, 'asds', '15-06-2017 10:34:11'),
(4, 3, 23, 'testttt', '24-06-2017 11:15:42');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `termination_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `termination_type` (
  `termination_type_id` int(111) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`termination_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `termination_type`
		--
		INSERT INTO `termination_type` (`termination_type_id`, `type`, `created_at`) VALUES
(1, 'Layoff', ''),
(2, 'Damaging Company Property', ''),
(3, 'Drug or Alcohol Possession at Work', ''),
(4, 'Falsifying Company Records', ''),
(5, 'Insubordination', ''),
(6, 'Misconduct', ''),
(7, 'Poor Performance', ''),
(8, 'Stealing', ''),
(9, 'Using Company Property for Personal Business', ''),
(10, 'Taking Too Much Time Off', ''),
(11, 'Violating Company Policy', ''),
(12, 'Voluntary Termination', ''),
(13, 'Involuntary Termination', ''),
(14, 'Discriminatory Conduct Towards others', ''),
(15, 'Harassment (Sexual and Otherwise)', '');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `tickets_attachment`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `tickets_attachment` (
  `ticket_attachment_id` int(11) NOT NULL,
  `ticket_id` int(200) NOT NULL,
  `upload_by` int(255) NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `file_description` text NOT NULL,
  `attachment_file` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`ticket_attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `tickets_comments`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `tickets_comments` (
  `comment_id` int(11) NOT NULL,
  `ticket_id` int(200) NOT NULL,
  `user_id` int(200) NOT NULL,
  `ticket_comments` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `tickets_comments`
		--
		INSERT INTO `tickets_comments` (`comment_id`, `ticket_id`, `user_id`, `ticket_comments`, `created_at`) VALUES
(5, 3, 23, 'asd', '2017-05-05 05:28:36'),
(6, 3, 23, 'asdwwww', '2017-05-05 05:32:56'),
(11, 1, 1, 'sfasdsd', '12-06-2017 04:24:38'),
(13, 1, 1, 'sdfadf', '12-06-2017 04:26:02'),
(15, 1, 23, 'sdfds', '24-06-2017 11:26:04');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `trainers`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `trainers` (
  `trainer_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `designation_id` int(111) NOT NULL,
  `expertise` text NOT NULL,
  `address` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`trainer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `trainers`
		--
		INSERT INTO `trainers` (`trainer_id`, `first_name`, `last_name`, `contact_number`, `email`, `designation_id`, `expertise`, `address`, `status`, `created_at`) VALUES
(1, 'Barbara', 'Young', 123456789, 'barbara@testemail.com', 15, 'ADSDsdSddddwwsd&lt;p&gt;&lt;/p&gt;', 'Test Address', 1, '28-04-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `training`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `training` (
  `training_id` int(11) NOT NULL,
  `employee_id` varchar(200) NOT NULL,
  `training_type_id` int(200) NOT NULL,
  `trainer_id` int(200) NOT NULL,
  `start_date` varchar(200) NOT NULL,
  `finish_date` varchar(200) NOT NULL,
  `training_cost` varchar(200) NOT NULL,
  `training_status` int(200) NOT NULL,
  `description` text NOT NULL,
  `performance` varchar(200) NOT NULL,
  `remarks` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `training`
		--
		INSERT INTO `training` (`training_id`, `employee_id`, `training_type_id`, `trainer_id`, `start_date`, `finish_date`, `training_cost`, `training_status`, `description`, `performance`, `remarks`, `created_at`) VALUES
(1, 23, 1, 1, '2017-04-03', '2017-04-07', 1500, 0, '&lt;p&gt;Test is a test description for job training..&lt;/p&gt;', 1, 'asd', '2017-04-28 06:36:49'),
(4, 24, 2, 1, '2017-06-01', '2017-06-03', 1233, 0, '&lt;p&gt;testttasdswwwdd&lt;/p&gt;', '', '', '03-06-2017 12:48:24');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `training_types`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `training_types` (
  `training_type_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`training_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `training_types`
		--
		INSERT INTO `training_types` (`training_type_id`, `type`, `created_at`, `status`) VALUES
(1, 'Job Training', '28-04-2017', 1),
(2, 'Promotional Training', '28-04-2017', 1),
(3, 'Workshop', '28-04-2017', 1),
(4, 'Webinar', '28-04-2017', 1),
(5, 'Seminar', '28-04-2017', 1),
(6, 'Online Training', '28-04-2017', 1);



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `travel_arrangement_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `travel_arrangement_type` (
  `arrangement_type_id` int(111) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`arrangement_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `travel_arrangement_type`
		--
		INSERT INTO `travel_arrangement_type` (`arrangement_type_id`, `type`, `status`, `created_at`) VALUES
(1, 'Personal Arrangment', 1, '2017-04-28 07:47:55'),
(2, 'Hotel', 1, '2017-04-28 07:48:00'),
(3, 'Guest House', 1, '2017-04-28 07:48:06'),
(4, 'Motel', 1, '2017-04-28 07:48:11'),
(5, 'AirBnB', 1, '2017-04-28 07:48:16');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `user_roles`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `user_roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(200) NOT NULL,
  `role_access` varchar(200) NOT NULL,
  `role_resources` text NOT NULL,
  `created_at` varchar(200) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `user_roles`
		--
		INSERT INTO `user_roles` (`role_id`, `role_name`, `role_access`, `role_resources`, `created_at`) VALUES
(0, 'HR Manager', 2, '0,3,4,5,6,13,22,26,29,31,32,34,35,53,54,56', '29-07-2018'),
(1, 'Super Admin', 1, '0,3,4,5,6,13,14,22,26,29,31,32,34,35,53,54,56', '20-11-2016'),
(9, 'Employees', 2, 0, '28-04-2017');



		-- ---------------------------------------------------------
		--
		-- Table structure for table : `warning_type`
		--
		-- ---------------------------------------------------------
		CREATE TABLE `warning_type` (
  `warning_type_id` int(111) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_at` varchar(255) NOT NULL,
  PRIMARY KEY (`warning_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

		--
		-- Dumping data for table `warning_type`
		--
		INSERT INTO `warning_type` (`warning_type_id`, `type`, `created_at`) VALUES
(1, 'Verbal Warning', '2017-04-28 07:43:33'),
(2, 'First Written Warning', '2017-04-28 07:43:38'),
(3, 'Second Written Warning', '2017-04-28 07:43:44'),
(4, 'Final Written Warning', '2017-04-28 07:43:49'),
(5, 'Incident Explanation Request', '2017-04-28 07:43:56');


		/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
		/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
		/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;